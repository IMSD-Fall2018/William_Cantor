﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rgb : MonoBehaviour
{
    public Color Color1;
    public Color Color2;
    public Color Color3;
    public Color Color4;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Q))
        {
            gameObject.GetComponent<Renderer>().material.color = Color1;

        }
        if (Input.GetKeyDown(KeyCode.W))
        {
            gameObject.GetComponent<Renderer>().material.color = Color.blue;
        }
        if (Input.GetKeyDown(KeyCode.E))
        {
            gameObject.GetComponent<Renderer>().material.color = Color.green;
        }

        if (Input.GetKeyDown(KeyCode.R))
        {
            gameObject.GetComponent<Renderer>().material.color = Color.magenta;
        }
    }
}